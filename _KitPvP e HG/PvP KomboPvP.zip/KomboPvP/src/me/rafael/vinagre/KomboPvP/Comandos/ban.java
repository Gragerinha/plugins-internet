package me.rafael.vinagre.KomboPvP.Comandos;

public class ban {

}
