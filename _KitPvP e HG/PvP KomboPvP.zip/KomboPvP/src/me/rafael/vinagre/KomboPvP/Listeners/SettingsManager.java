package me.rafael.vinagre.KomboPvP.Listeners;

public class SettingsManager {

}
